# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '5f6c4e721dd14155770d3266b41da917440f375bd26d887d4dd243eaf9f2b1fe20bca53f4cd7d9f11f5013156e9658d831ee1565d19c03b8b0563a49ff53dff1'